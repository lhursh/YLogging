//
//  YLogging.h
//  YLogging
//
//  Created by xamarin-mm-sa on 8/3/18.
//  Copyright © 2018 Listrak. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for YLogging.
FOUNDATION_EXPORT double YLoggingVersionNumber;

//! Project version string for YLogging.
FOUNDATION_EXPORT const unsigned char YLoggingVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <YLogging/PublicHeader.h>


